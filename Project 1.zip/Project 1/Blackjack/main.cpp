#include <iostream>
#include <vector>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <string>
#include <iterator>
#include <cassert>



// Constants for the game
const int BLACKJACK = 21;  

// The score required to win Blackjack

const int MAX_SCORE = 21;  

// Maximum score allowed before busting

const int INITIAL_CHIPS = 1000;  

// Starting number of chips for each player

const int MIN_BET = 10;  

// Minimum bet for each round

const int MAX_BET = 500;  

// Maximum bet for each round

const int MAX_PLAYERS = 4;  

// Maximum number of players allowed




// Card class: Represents a single playing card with a suit and rank

class Card {
public:
    
    // Enumeration for the four suits
    
    enum Suit { HEARTS, DIAMONDS, CLUBS, SPADES };
    
    
    
    // Enumeration for the card ranks
    
    enum Rank { TWO = 2, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK = 10, QUEEN = 10, KING = 10, ACE = 11 };

    
    
private:
    Suit suit;  
    
    // Suit of the card (Hearts, Diamonds, Clubs, Spades)
    
    Rank rank;  
    
    // Rank of the card (2-10, Jack, Queen, King, Ace)
    

    
    
public:
    
    // Constructor that initializes the card with a suit and rank
    
    Card(Suit s, Rank r) : suit(s), rank(r) {}

    
    
    // Getter for the rank of the card
    
    Rank getRank() const { return rank; }

    
    
    // Getter for the suit of the card
    
    Suit getSuit() const { return suit; }

    
    
    // Convert the card to a string for display purposes
    
    std::string toString() const {
        static const std::string rankStr[] = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A" };
        static const std::string suitStr[] = { "Hearts", "Diamonds", "Clubs", "Spades" };
        return rankStr[rank - 2] + " of " + suitStr[suit];
    }

    
    
    // Overload the equality operator to compare two cards
    
    bool operator==(const Card& other) const {
        return suit == other.suit && rank == other.rank;
    }

    
    
    // Overload the less-than operator to allow sorting cards (needed for hand sorting)
    
    bool operator<(const Card& other) const {
        if (rank == other.rank) {
            return suit < other.suit;
        }
        return rank < other.rank;
    }
};



// Deck class: Represents a deck of 52 playing cards

class Deck {
private:
    std::vector<Card> deck;  
    
    // Vector to store all 52 cards in the deck
    
    unsigned int currentCardIndex;  
    
    // Index of the next card to deal

    
    
public:
    
    // Constructor to initialize the deck with 52 cards and shuffle it
    
    Deck() : currentCardIndex(0) {
        for (int suit = Card::HEARTS; suit <= Card::SPADES; ++suit) {
            for (int rank = Card::TWO; rank <= Card::ACE; ++rank) {
                deck.push_back(Card(static_cast<Card::Suit>(suit), static_cast<Card::Rank>(rank)));
            }
        }
        std::random_shuffle(deck.begin(), deck.end());  
        
        // Shuffle the deck initially
    }

    
    
    // Deal the next card from the deck
    
    Card dealCard() {
        
        // If all cards have been dealt, reshuffle the deck
        
        if (currentCardIndex >= deck.size()) {
            std::cerr << "Deck is empty! Reshuffling..." << std::endl;
            resetDeck();  
            
            // Reshuffle the deck when it's empty
            
        }
        return deck[currentCardIndex++];  
        
        // Return the current card and move the index forward
        
    }

    
    
    
    // Reset the deck and reshuffle it (called when the deck runs out of cards)
    
    void resetDeck() {
        currentCardIndex = 0;  
        
        // Reset the index to the start of the deck
        
        std::random_shuffle(deck.begin(), deck.end());  
        
        // Shuffle the deck again
        
    }

    
    
    // Return the number of cards left in the deck
    
    unsigned int cardsLeft() const {
        return deck.size() - currentCardIndex; 
        
        // Cards remaining in the deck
        
    }

    
    
    // Debugging function to print the entire deck of cards
    
    void printDeck() const {
        for (const auto& card : deck) {
            std::cout << card.toString() << std::endl;
        }
    }
};



// Hand class: Represents the player's hand (a collection of cards)

class Hand {
private:
    std::vector<Card> cards;  
    
    // Cards in the player's hand
    
    int score;  
    
    // The current score of the hand
    
    bool hasAce;  
    
    // Flag indicating if the hand contains an Ace

    
    
public:
    
    // Constructor to initialize an empty hand
    
    Hand() : score(0), hasAce(false) {}

    
    
    // Add a card to the hand and update the score
    
    void addCard(const Card& card) {
        cards.push_back(card);  
        
        // Add the card to the hand
        
        score += card.getRank();  
        
        // Add the card's rank to the score

        
        
        // If the card is an Ace, mark the hand as containing an Ace
        
        if (card.getRank() == Card::ACE) {
            hasAce = true;
        }

        
        
        // If the score exceeds 21 and the hand contains an Ace, adjust the Ace value from 11 to 1
        
        if (score > BLACKJACK && hasAce) {
            score -= 10;  
            
            // Consider Ace as 1 instead of 11
            
            hasAce = false;  
            
            // Ace is no longer counted as 11
        }
    }

    
    
    // Get the current score of the hand
    
    int getScore() const { return score; }

    
    
    // Get the number of cards in the hand
    
    size_t getCardCount() const { return cards.size(); }

    
    
    // Check if the hand has busted (score exceeds 21)
    
    bool isBusted() const { return score > MAX_SCORE; }

    
    
    // Print the cards in the hand along with the current score
    
    void printHand() const {
        for (const auto& card : cards) {
            std::cout << card.toString() << ", ";  
            
            // Print each card in the hand
        }
        std::cout << "Score: " << score << std::endl;  
        
        // Print the current score of the hand
        
    }

    
    
    // Clear the hand for a new round (reset cards and score)
    
    void clearHand() {
        cards.clear();  
        // Clear the vector of cards
        
        score = 0;  
        
        // Reset the score
        
        hasAce = false;  
        
        // Reset the Ace flag
        
    }

    
    
    // Sort the hand (useful for debugging or future game features)
    
    void sortHand() {
        std::sort(cards.begin(), cards.end());  
        
        // Sort the cards in ascending order
        
    }

    
    
    // Debugging function to print the hand's cards and score in a more detailed format
    
    void printHandDebug() const {
        std::cout << "Debugging hand: ";
        for (const auto& card : cards) {
            std::cout << card.toString() << " ";  
            
            // Print each card
            
        }
        std::cout << "Total Score: " << score << std::endl;  
        
        // Print the total score
        
    }
};



// Abstract Player class: Represents a generic player in the game

class Player {
protected:
    std::string name;  
    
    // Player's name
    
    Hand hand;  
    
    // Player's hand (set of cards)
    
    int chips;  
    
    // Player's chips (money)
    
    bool isBust;  
    
    // Flag indicating if the player has busted
    
    int currentBet;  
    
    // Player's current bet for the round
    

    
    
public:
    
    
    // Constructor that initializes the player with a name and chips
    
    Player(const std::string& playerName) : name(playerName), chips(INITIAL_CHIPS), isBust(false), currentBet(0) {}

    
    
    
    // Getter for the player's name
    
    std::string getName() const { return name; }

    
    
    
    // Getter for the player's chips
    
    int getChips() const { return chips; }

    
    
    
    // Setter for the player's chips (validates that chips cannot be negative)
    
    void setChips(int amount) {
        if (amount < 0) {
            std::cout << "Error: Cannot set negative chips!" << std::endl;
            exit(1);
        }
        chips = amount;
    }

    
    
    
    // Add chips to the player's total
    
    void addChips(int amount) {
        if (amount < 0) {
            std::cout << "Error: Cannot add negative chips!" << std::endl;
            exit(1);
        }
        chips += amount;  
        
        // Add the specified amount of chips
        
    }

    
    
    
    // Subtract chips from the player's total
    
    void subtractChips(int amount) {
        if (amount < 0) {
            std::cout << "Error: Cannot subtract negative chips!" << std::endl;
            exit(1);
        }
        if (chips < amount) {
            std::cout << "Error: Not enough chips!" << std::endl;
            exit(1);
        }
        chips -= amount;  
        // Subtract the specified amount of chips
        
    }

    
    
    // Getter for the player's hand
    
    Hand& getHand() { return hand; }

    // Print the player's hand and chip count
    
    void printHand() const {
        hand.printHand();  
        // Print the player's cards
        std::cout << name << " has " << chips << " chips left." << std::endl;  // Print the player's chips
    }

    
    
    // Check if the player has busted
    bool hasBusted() const { return hand.isBusted(); }

    // Abstract method for the player's turn (to be implemented by derived classes)
    virtual void takeTurn(Deck& deck) = 0;

    
    
    // Allow player to place a bet
    void placeBet() {
        std::cout << name << ", enter your bet (minimum: " << MIN_BET << ", maximum: " << MAX_BET << "): ";
        std::cin >> currentBet;

        
        
        // Validate the bet amount
        while (currentBet < MIN_BET || currentBet > MAX_BET || currentBet > chips) {
            std::cout << "Invalid bet! Please enter a bet between " << MIN_BET << " and " << MAX_BET
                      << ", and no more than your current chips (" << chips << "): ";
            std::cin >> currentBet;
        }

        
        
        subtractChips(currentBet);  // Subtract the bet from the player's chips
        std::cout << "Bet placed: " << currentBet << " chips." << std::endl;
    }

    
    
    // Get the player's current bet
    int getBet() const { return currentBet; }

    
    
    // Reset the player's current bet (useful after each round)
    void resetBet() {
        currentBet = 0;
    }
};



// HumanPlayer class: Represents the human player, allowing user input for decisions
class HumanPlayer : public Player {
public:
    // Constructor to initialize the player with a name
    HumanPlayer(const std::string& playerName) : Player(playerName) {}

    
    
    // Override the takeTurn function to allow user input during their turn
    void takeTurn(Deck& deck) override {
        char action;
        while (!hasBusted()) {
            printHand();  // Print the player's current hand and chips
            std::cout << "Do you want to (h)it, (s)tand, or (d)ouble down? ";
            std::cin >> action;  // Get the player's choice

            if (action == 'h') {
                hand.addCard(deck.dealCard());  // Player chooses to hit
                std::cout << name << " drew a card." << std::endl;
            } else if (action == 's') {
                std::cout << name << " stands." << std::endl;  // Player chooses to stand
                break;  // End their turn
            } else if (action == 'd') {
                // Double down: player places an additional bet equal to their initial bet
                if (chips >= currentBet) {
                    chips -= currentBet;  // Subtract the bet again (double the amount)
                    currentBet *= 2;  // Double the bet amount
                    hand.addCard(deck.dealCard());  // Draw one more card
                    std::cout << name << " doubled down!" << std::endl;
                    break;  // End the turn after doubling down
                } else {
                    std::cout << "You don't have enough chips to double down!" << std::endl;
                }
            } else {
                std::cout << "Invalid action! Please choose 'h', 's', or 'd'." << std::endl;
            }
        }
    }
};



// ComputerPlayer class: Represents the dealer (AI player), which follows a simple strategy
class ComputerPlayer : public Player {
public:
    // Constructor that calls the base class constructor
    ComputerPlayer(const std::string& playerName) : Player(playerName) {}

    // Override the takeTurn function to implement dealer's automatic behavior
    void takeTurn(Deck& deck) override {
        // Dealer follows basic Blackjack rules: hit if score is less than 17
        while (hand.getScore() < 17 && !hasBusted()) {
            std::cout << name << " hits." << std::endl;
            hand.addCard(deck.dealCard());  // Dealer draws a card
        }

        if (hand.getScore() >= 17) {
            std::cout << name << " stands." << std::endl;  // Dealer stands at 17 or higher
        }
    }
};



// BlackjackGame class: Manages the overall game flow, rounds, and player interactions
class BlackjackGame {
private:
    Deck deck;  // The deck used for the game
    std::vector<Player*> players;  // A list of players (can include both human and computer players)
    bool gameOver;  // Flag indicating if the game is over
    int roundNumber;  // Current round number (used for display purposes)

    
    
public:
    // Constructor to initialize the game
    BlackjackGame() : gameOver(false), roundNumber(0) {}

    // Add a player to the game (can be a human or computer player)
    void addPlayer(Player* player) {
        if (players.size() < MAX_PLAYERS) {
            players.push_back(player);
        } else {
            std::cout << "Maximum number of players reached!" << std::endl;
        }
    }

    
    
    // Start a new round of Blackjack
    void startNewRound() {
        // Clear previous round data (hands, bets, etc.)
        for (auto& player : players) {
            player->getHand().clearHand();
            player->resetBet();
        }

        
        
        // Increment round number and display round info
        roundNumber++;
        std::cout << "\nRound " << roundNumber << " begins!" << std::endl;

        // Allow players to place their bets
        for (auto& player : players) {
            player->placeBet();
        }

        
        
        // Deal initial cards
        for (auto& player : players) {
            player->getHand().addCard(deck.dealCard());
            player->getHand().addCard(deck.dealCard());
        }

        
        
        // Each player takes their turn
        for (auto& player : players) {
            std::cout << "\n" << player->getName() << "'s turn:" << std::endl;
            player->takeTurn(deck);
        }

        
        
        // Dealer's turn if no player has busted
        if (!anyPlayerBusted()) {
            std::cout << "\nDealer's turn:" << std::endl;
            for (auto& player : players) {
                if (ComputerPlayer* dealer = dynamic_cast<ComputerPlayer*>(player)) {
                    dealer->takeTurn(deck);
                    break;  // Only one dealer
                }
            }
        }

        
        
        // Determine the winner and update chips
        determineWinner();
    }

    
    
    // Helper function to check if any player has busted
    bool anyPlayerBusted() {
        for (auto& player : players) {
            if (player->hasBusted()) {
                return true;
            }
        }
        return false;
    }

    
    
    // Determine the winner of the current round based on hand scores
    void determineWinner() {
        int dealerScore = 0;
        int bestPlayerScore = 0;
        Player* winner = nullptr;

        // Find the dealer's score
        for (auto& player : players) {
            if (ComputerPlayer* dealer = dynamic_cast<ComputerPlayer*>(player)) {
                dealerScore = dealer->getHand().getScore();
                break;
            }
        }

        
        
        // Compare each player's score to determine the winner
        for (auto& player : players) {
            if (!player->hasBusted()) {
                int playerScore = player->getHand().getScore();
                if (playerScore > bestPlayerScore) {
                    bestPlayerScore = playerScore;
                    winner = player;
                }
            }
        }

        
        
        // Compare dealer's score with the best player score
        if (winner != nullptr) {
            std::cout << winner->getName() << " wins the round!" << std::endl;
        } else {
            std::cout << "Dealer wins the round!" << std::endl;
        }
    }

    
    
    // Main game loop
    void playGame() {
        while (!gameOver) {
            startNewRound();  // Start a new round of Blackjack

            
            
            // Ask player if they want to continue or quit
            char choice;
            std::cout << "Do you want to play another round? (y/n): ";
            std::cin >> choice;

            
            
            // If the player doesn't want to play, end the game
            if (choice != 'y') {
                gameOver = true;
                std::cout << "Thank you for playing!" << std::endl;
            }
        }
    }
};



// Main function to run the Blackjack game
int main() {
    // Create a Blackjack game instance
    BlackjackGame game;

    
    
    // Add players (you can add more players if needed)
    HumanPlayer* player1 = new HumanPlayer("Alice");
    game.addPlayer(player1);

    
    
    ComputerPlayer* dealer = new ComputerPlayer("Dealer");
    game.addPlayer(dealer);

    
    
    // Start the game
    game.playGame();

    
    
    return 0;
}