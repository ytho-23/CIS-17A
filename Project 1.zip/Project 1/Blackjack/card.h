class Hand {
private:
    list<Card> handCards; // List of cards in hand
    int handValue; // Sum of card values

public:
    Hand() : handValue(0) {}

    void addCard(const Card& card) {
        handCards.push_back(card);
        handValue += card.value;
    }

    int getHandValue() const {
        return handValue;
    }

    void displayHand() const {
        for (const auto& card : handCards) {
            card.display();
            cout << " ";
        }
        cout << "Value: " << handValue << endl;
    }
};