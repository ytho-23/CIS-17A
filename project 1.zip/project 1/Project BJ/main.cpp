#include <iostream>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <fstream>
#include <cstring>

using namespace std;

// Enum to represent suits and ranks of cards
enum Suit { HEARTS, DIAMONDS, CLUBS, SPADES };
enum Rank { TWO = 2, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING, ACE };

// Structure for a card
struct Card {
    Suit suit;
    Rank rank;

    const char* toString() const {
        const char* suits[] = {"Hearts", "Diamonds", "Clubs", "Spades"};
        const char* ranks[] = {"", "", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        return (string(ranks[rank]) + " of " + suits[suit]).c_str();
    }

    int value() const {
        if (rank >= JACK) return 10;
        return (int)rank;
    }
};

// Global variables
vector<Card> deck;
string playerName;
vector<Card> playerHand;
vector<Card> dealerHand;

// Function to initialize the deck with 52 cards
void initializeDeck() {
    deck.clear();
    for (int s = HEARTS; s <= SPADES; ++s) {
        for (int r = TWO; r <= ACE; ++r) {
            deck.push_back({static_cast<Suit>(s), static_cast<Rank>(r)});
        }
    }
}

// Shuffle the deck using Fisher-Yates algorithm
void shuffleDeck() {
    srand(time(0));
    for (int i = deck.size() - 1; i > 0; --i) {
        int j = rand() % (i + 1);
        swap(deck[i], deck[j]);
    }
}

// Deal a card from the deck
Card dealCard() {
    Card card = deck.back();
    deck.pop_back();
    return card;
}

// Calculate the hand value considering Aces as 1 or 11
int calculateHandValue(const vector<Card>& hand) {
    int value = 0;
    int aces = 0;
    for (const auto& card : hand) {
        value += card.value();
        if (card.rank == ACE) aces++;
    }
    while (aces && value <= 11) {
        value += 10;
        --aces;
    }
    return value;
}

// Show the player's or dealer's hand
void showHand(const vector<Card>& hand, bool hideFirstCard = false) {
    if (hideFirstCard) {
        cout << "Hidden card, ";
    } else {
        for (size_t i = 0; i < hand.size(); ++i) {
            cout << hand[i].toString() << (i < hand.size() - 1 ? ", " : "");
        }
    }
    cout << endl;
}

// Clear a player's hand
void clearHand(vector<Card>& hand) {
    hand.clear();
}

// Display the main menu
int displayMenu() {
    int choice;
    cout << "Blackjack Game Menu\n";
    cout << "1. Start New Game\n";
    cout << "2. Exit\n";
    cout << "Enter your choice: ";
    cin >> choice;
    return choice;
}

// Save player data (name) to a binary file
void savePlayerData() {
    ofstream outFile("player_data.dat", ios::binary);
    if (!outFile) {
        cout << "Error opening file for saving player data." << endl;
        return;
    }
    size_t nameLength = playerName.size();
    outFile.write(reinterpret_cast<const char*>(&nameLength), sizeof(nameLength));
    outFile.write(playerName.c_str(), nameLength);
    outFile.close();
}

// Load player data (name) from a binary file
void loadPlayerData() {
    ifstream inFile("player_data.dat", ios::binary);
    if (!inFile) {
        cout << "Error opening file for loading player data." << endl;
        return;
    }
    size_t nameLength;
    inFile.read(reinterpret_cast<char*>(&nameLength), sizeof(nameLength));
    char* nameBuffer = new char[nameLength + 1];
    inFile.read(nameBuffer, nameLength);
    nameBuffer[nameLength] = '\0';
    playerName = nameBuffer;
    delete[] nameBuffer;
    inFile.close();
}

// Function to play a round of Blackjack
void playRound() {
    clearHand(playerHand);
    clearHand(dealerHand);

    // Deal initial cards to player and dealer
    playerHand.push_back(dealCard());
    dealerHand.push_back(dealCard());
    playerHand.push_back(dealCard());
    dealerHand.push_back(dealCard());

    // Show initial hands (dealer hides first card)
    cout << "\nPlayer's Hand: ";
    showHand(playerHand);
    cout << "Dealer's Hand: ";
    showHand(dealerHand, true);

    // Player's turn
    bool playerBusted = false;
    while (calculateHandValue(playerHand) < 21) {
        cout << "Your hand value is: " << calculateHandValue(playerHand) << endl;
        cout << "Do you want to (1) Hit or (2) Stand? ";
        int choice;
        cin >> choice;
        if (choice == 1) {
            playerHand.push_back(dealCard());
            cout << "You drew: " << playerHand.back().toString() << endl;
        } else {
            break;
        }
    }

    if (calculateHandValue(playerHand) > 21) {
        playerBusted = true;
        cout << "You busted! Dealer wins." << endl;
        return;
    }

    // Dealer's turn (dealer hits until hand value is 17 or higher)
    while (calculateHandValue(dealerHand) < 17) {
        dealerHand.push_back(dealCard());
    }

    // Show final hands
    cout << "\nPlayer's Final Hand: ";
    showHand(playerHand);
    cout << "Dealer's Final Hand: ";
    showHand(dealerHand);

    // Determine the winner
    if (calculateHandValue(dealerHand) > 21) {
        cout << "Dealer busts! You win!" << endl;
    } else if (calculateHandValue(playerHand) > calculateHandValue(dealerHand)) {
        cout << "You win!" << endl;
    } else if (calculateHandValue(playerHand) < calculateHandValue(dealerHand)) {
        cout << "Dealer wins!" << endl;
    } else {
        cout << "It's a tie!" << endl;
    }
}

// Main function to drive the game
int main() {
    int menuChoice;

    while ((menuChoice = displayMenu()) != 2) {
        if (menuChoice == 1) {
            cout << "Enter your name: ";
            cin >> playerName;

            // Initialize and shuffle the deck
            initializeDeck();
            shuffleDeck();

            // Load player data if available
            loadPlayerData();

            // Play a round of Blackjack
            playRound();

            // Save player data after the round
            savePlayerData();
        } else {
            cout << "Invalid choice, try again." << endl;
        }
    }

    cout << "Thanks for playing Blackjack!" << endl;
    return 0;
}