#ifndef BLACKJACK_H
#define BLACKJACK_H

#include <iostream>
#include <string>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <vector>
#include <memory>

// Enum for Card Ranks
enum Rank { TWO = 2, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING, ACE };

// Enum for Card Suits
enum Suit { CLUBS, DIAMONDS, HEARTS, SPADES };

// Union to hold card details
union CardDetails {
    int rank;  // Rank of the card (2 to 14, where 11 = JACK, 12 = QUEEN, 13 = KING, 14 = ACE)
    char face; // For string representation (J, Q, K, A)
};

// Struct to represent a Card
struct Card {
    Suit suit;
    CardDetails details;
};

// Struct for Player
struct Player {
    std::string name;
    std::vector<Card> hand;
    int score;

    void addCard(Card card);
    void clearHand();
    int calculateScore();
};

// Class for Deck of Cards
class Deck {
public:
    Deck();
    void shuffleDeck();
    Card dealCard();
    int remainingCards();

private:
    std::vector<Card> cards;
    int cardIndex;
};

// Function declarations
void startGame();
void printCard(const Card& card);
void printDeck(const Deck& deck);
void displayScore(const Player& player);
bool checkBlackjack(const Player& player);
void saveGame(const Player& player, const std::string& filename);
bool loadGame(Player& player, const std::string& filename);

#endif // BLACKJACK_H